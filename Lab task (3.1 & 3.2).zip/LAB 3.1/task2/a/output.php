<?php
    $email = $_POST['email'];
    echo "your email is " . $email;
?>