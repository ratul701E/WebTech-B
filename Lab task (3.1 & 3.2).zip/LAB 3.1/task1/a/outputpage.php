<?php
    $name = $_POST['name'];
    echo 'Name is '. $name;
?>