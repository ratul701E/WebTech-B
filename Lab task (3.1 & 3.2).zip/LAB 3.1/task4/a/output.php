<?php
    $gender = $_POST['gender'];
    echo "your gender is " . $gender;
?>