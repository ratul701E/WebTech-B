<?php
    $group = $_POST['group'];
    echo "Your Blood group is {$group}";
?>