<?php
    $date = $_POST['date'];
    $mnth = $_POST['month'];
    $year = $_POST['year'];
    echo "Date: {$date}/{$mnth}/{$year}";
?>